# library 
- [bh1750](https://github.com/flrrth/pico-bh1750?tab=readme-ov-file)

# 라이브러리를 복사시키는 스크립트
